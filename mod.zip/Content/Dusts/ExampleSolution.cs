using Terraria.ModLoader;

namespace ExampleMod.Content.Dusts
{
	public class ExampleSolution : ModDust
	{
		public override void SetStaticDefaults() {
			UpdateType = 110;
		}
	}
}